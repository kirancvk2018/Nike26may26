
class InventoryRepository:

    async def get_inventory_by_sku(self, sku: str):
        return {
            "sku": sku,
            "available_stock": 100
        }
