
from fastapi import APIRouter, Depends
from app.schemas.checkout_schema import CheckoutRequest
from app.services.checkout_service import CheckoutService

router = APIRouter()

@router.post("/checkout")
async def checkout(
    request: CheckoutRequest,
    service: CheckoutService = Depends()
):
    return await service.process_checkout(request)
