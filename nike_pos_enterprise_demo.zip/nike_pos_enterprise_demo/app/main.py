
from fastapi import FastAPI
from app.api.v1.checkout_controller import router as checkout_router

app = FastAPI(title="Nike POS Platform")

app.include_router(checkout_router, prefix="/api/v1")
