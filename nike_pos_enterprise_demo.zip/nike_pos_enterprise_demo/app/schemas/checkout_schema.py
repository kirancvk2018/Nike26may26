
from pydantic import BaseModel
from typing import List

class CheckoutItem(BaseModel):
    sku: str
    quantity: int
    price: float

class CheckoutRequest(BaseModel):
    store_id: str
    customer_id: str
    items: List[CheckoutItem]
