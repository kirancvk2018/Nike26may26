
import logging
from app.schemas.checkout_schema import CheckoutRequest

logger = logging.getLogger(__name__)

class CheckoutService:

    async def process_checkout(self, request: CheckoutRequest):
        logger.info(
            "processing_checkout",
            extra={
                "store_id": request.store_id,
                "customer_id": request.customer_id
            }
        )

        total = sum(item.quantity * item.price for item in request.items)

        return {
            "status": "success",
            "total_amount": total
        }
