
# AFTER Rules Demo Prompts

Use these prompts AFTER enabling skills.md and .cursorrules.

## Prompt 1

Create a production-grade checkout API for Nike POS using Controller -> Service -> Repository architecture with structured logging, validation, audit trails, and pytest coverage.

## Prompt 2

Build enterprise footwear inventory APIs with size-level inventory tracking, pagination, async SQLAlchemy repositories, validation, and audit logging.

## Prompt 3

Implement Nike loyalty discount workflows ensuring discounts never exceed 30%, including manager override support and structured audit events.

## Prompt 4

Build secure product return APIs with manager approval for returns above $500 and enterprise validation standards.

## Prompt 5

Create scalable sales analytics APIs with pagination, filters, caching strategy recommendations, and pytest coverage.

## What You'll Notice

- Enterprise architecture
- Better naming
- Security-aware code
- Structured logging
- Better validation
- Cleaner APIs
- Better testing
- Nike-specific business logic
