
# BEFORE Rules Demo Prompts

Use these prompts BEFORE enabling skills.md and .cursorrules.

## Prompt 1

Create a checkout API for Nike POS.

## Prompt 2

Build inventory update endpoint for footwear products.

## Prompt 3

Add loyalty discount calculation logic.

## Prompt 4

Implement return order API.

## Prompt 5

Create sales analytics API.

## What You'll Notice

- Generic code
- Weak architecture
- Missing validations
- No enterprise logging
- Minimal testing
- Inconsistent patterns
