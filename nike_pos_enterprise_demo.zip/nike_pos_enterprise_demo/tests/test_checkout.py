
from app.services.checkout_service import CheckoutService
from app.schemas.checkout_schema import CheckoutRequest, CheckoutItem
import pytest

@pytest.mark.asyncio
async def test_checkout_total():
    service = CheckoutService()

    request = CheckoutRequest(
        store_id="BLR001",
        customer_id="CUST100",
        items=[
            CheckoutItem(
                sku="NK-001",
                quantity=2,
                price=100
            )
        ]
    )

    result = await service.process_checkout(request)

    assert result["total_amount"] == 200
