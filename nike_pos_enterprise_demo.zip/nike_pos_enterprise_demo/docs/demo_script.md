
# Live Demo Script

## Step 1 — Open Project WITHOUT rules

Temporarily rename:
- skills.md
- .cursorrules

Ask:
"Create a product return API"

Observe generic AI behavior.

## Step 2 — Restore rules

Re-enable:
- skills.md
- .cursorrules

Ask SAME prompt again.

## Expected Improvements

- Better architecture
- Security checks
- Validation
- Logging
- Nike business rules
- Enterprise naming
- Better testing

## Powerful Demo Prompt

"Build Nike footwear inventory APIs supporting size-level stock tracking, audit logging, pagination, pytest coverage, repository pattern, and async workflows."

This usually produces dramatically better enterprise code after rules are enabled.
