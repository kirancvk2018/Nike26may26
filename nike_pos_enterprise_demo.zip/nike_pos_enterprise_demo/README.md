
# Nike POS Enterprise AI Demo

This project demonstrates how Cursor AI behaves:
1. WITHOUT enterprise context
2. WITH `skills.md` and `.cursorrules`

The project simulates an enterprise-grade Nike Point of Sale (POS) backend system.

## Tech Stack
- Python
- FastAPI
- PostgreSQL
- SQLAlchemy
- Pydantic
- Pytest

## Demo Goal

Use this project inside Cursor to demonstrate:
- AI consistency
- Architecture enforcement
- Enterprise governance
- Security-aware code generation
- Before vs After AI prompting quality

## Suggested Demo Flow

### Demo 1 — WITHOUT skills/rules
Ask Cursor:
"Create inventory checkout API"

Observe:
- mixed architecture
- weak validation
- inconsistent naming
- no audit logging

### Demo 2 — WITH skills/rules
Enable:
- skills.md
- .cursorrules

Ask the SAME prompt again.

Observe:
- clean layered architecture
- validation
- logging
- repository pattern
- enterprise naming
- Nike-specific business logic
