
# Nike POS Enterprise Skills

## Project Overview

This is Nike's enterprise-grade Point of Sale (POS) backend platform.

The platform handles:
- Store checkout
- Product inventory
- Loyalty management
- Returns processing
- Payment workflows
- Regional tax calculations
- Real-time stock synchronization

## Tech Stack

- FastAPI
- PostgreSQL
- SQLAlchemy
- Pydantic
- Pytest

## Architecture

Follow strict layered architecture:

Controllers -> Services -> Repositories -> Database

Controllers must remain thin.

Business logic belongs ONLY in services.

Repositories handle database operations.

## Coding Standards

- Use type hints everywhere
- Async/await only
- Use dependency injection
- Use Pydantic request validation
- Generate structured logging
- Use snake_case naming

## Nike POS Business Rules

- Footwear inventory must track size-wise stock
- Apparel inventory tracks color and size variants
- Loyalty discounts cannot exceed 30%
- Flash-sale products require audit logging
- Returns above $500 require manager approval
- Every transaction requires region-specific tax calculation

## Security Rules

- Never expose secrets
- Never log payment tokens
- Validate all user inputs
- Use parameterized queries only
- Sanitize barcode inputs

## Testing Standards

- Generate pytest test cases
- Mock payment gateways
- Mock external APIs
- Cover happy and failure paths

## Logging

Use structured enterprise logging:

logger.info("inventory_updated", extra={
    "sku": sku,
    "store_id": store_id
})

## API Standards

- REST APIs only
- Versioned APIs
- Standard response models
- Proper HTTP status codes

## Performance

- Avoid N+1 queries
- Use pagination
- Batch inventory updates
- Optimize DB calls

## AI Behavior Guidance

- Explain architecture before generating code
- Ask clarifying questions if requirements are ambiguous
- Never modify multiple files without explanation
