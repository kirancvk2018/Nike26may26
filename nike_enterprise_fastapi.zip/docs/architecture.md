
# Nike Inventory Service

## Architecture
- FastAPI REST layer
- Service layer for business logic
- Repository layer (in-memory DB)
- Pydantic schemas
