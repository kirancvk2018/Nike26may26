
from fastapi import APIRouter
from app.schemas.inventory_schema import InventoryItemCreate
from app.services.inventory_service import InventoryService

router = APIRouter(prefix="/inventory", tags=["Inventory"])
service = InventoryService()

@router.post("/add")
def add_item(item: InventoryItemCreate):
    return service.add_item(item)

@router.get("/all")
def get_all():
    return service.get_all_items()
