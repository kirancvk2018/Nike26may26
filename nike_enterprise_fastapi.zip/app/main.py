
from fastapi import FastAPI
from app.api.inventory_routes import router as inventory_router

app = FastAPI(title="Nike Inventory Service")

app.include_router(inventory_router)

@app.get("/")
def root():
    return {"message": "Nike Inventory Service Running"}
