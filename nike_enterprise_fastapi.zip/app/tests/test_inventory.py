
from app.services.inventory_service import InventoryService

def test_add_item():
    service = InventoryService()
    item = type("obj", (), {"dict": lambda self: {"sku": "1", "name": "shoe", "quantity": 10}})()
    result = service.add_item(item)
    assert result["status"] == "saved"
