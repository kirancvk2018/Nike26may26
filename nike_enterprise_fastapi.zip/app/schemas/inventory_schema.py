
from pydantic import BaseModel

class InventoryItemCreate(BaseModel):
    sku: str
    name: str
    quantity: int
