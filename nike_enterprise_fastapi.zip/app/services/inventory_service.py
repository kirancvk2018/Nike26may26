
from app.repository.inventory_repo import InventoryRepository

class InventoryService:
    def __init__(self):
        self.repo = InventoryRepository()

    def add_item(self, item):
        return self.repo.save(item)

    def get_all_items(self):
        return self.repo.get_all()
