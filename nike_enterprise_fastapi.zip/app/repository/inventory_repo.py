
class InventoryRepository:
    def __init__(self):
        self.db = []

    def save(self, item):
        self.db.append(item.dict())
        return {"status": "saved", "item": item}

    def get_all(self):
        return self.db
