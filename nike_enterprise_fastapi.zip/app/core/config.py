
class Settings:
    APP_NAME = "Nike Inventory Service"

settings = Settings()
