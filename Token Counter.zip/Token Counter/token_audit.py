"""
Enterprise AI Context & Token Auditor for Cursor / VS Code
----------------------------------------------------------

Purpose:
- Calculate estimated token consumption WITHOUT calling any LLM
- Scan ALL possible files that contribute to AI context
- Show remaining context window
- Categorize token usage
- Detect oversized files
- Estimate hidden prompt overhead

Works Offline:
- No API calls
- No token usage
- No telemetry

Install:
    pip install tiktoken rich

Run:
    python token_audit.py

Optional:
    python token_audit.py --model claude
    python token_audit.py --model gpt4o
    python token_audit.py --top 50

Supported Models:
- claude      -> 200K
- gpt4o       -> 128K
- gemini      -> 1M
- custom      -> specify manually

Author:
Enterprise AI Engineering Utility
"""

from pathlib import Path
from collections import defaultdict
import argparse
import os
import fnmatch
import json

try:
    import tiktoken
except ImportError:
    print("Install dependency:")
    print("pip install tiktoken rich")
    exit()

try:
    from rich.console import Console
    from rich.table import Table
    from rich.progress import track
except ImportError:
    print("Install dependency:")
    print("pip install rich")
    exit()

console = Console()

# =========================================================
# MODEL CONTEXT WINDOWS
# =========================================================

MODEL_CONTEXT_WINDOWS = {
    "claude": 200_000,
    "gpt4o": 128_000,
    "gemini": 1_000_000,
    "deepseek": 128_000,
}

# =========================================================
# FILE CATEGORIES
# =========================================================

CATEGORY_RULES = {
    "cursor_rules": [
        ".cursorrules",
        ".cursor/rules/*",
        ".cursor/rules/**/*.md",
    ],
    "copilot_rules": [
        ".github/copilot-instructions.md",
    ],
    "markdown_docs": [
        "*.md",
        "*.mdx",
        "README*",
        "CHANGELOG*",
        "ARCHITECTURE*",
        "SPEC*",
        "PRD*",
        "DESIGN*",
    ],
    "prompts": [
        "*.prompt",
        "*prompt*",
        "*system*",
        "*instruction*",
    ],
    "python": [
        "*.py",
        "*.ipynb",
    ],
    "javascript_typescript": [
        "*.js",
        "*.ts",
        "*.tsx",
        "*.jsx",
    ],
    "java": [
        "*.java",
    ],
    "go": [
        "*.go",
    ],
    "rust": [
        "*.rs",
    ],
    "c_cpp": [
        "*.c",
        "*.cpp",
        "*.h",
        "*.hpp",
    ],
    "configs": [
        "*.json",
        "*.yaml",
        "*.yml",
        "*.toml",
        "*.ini",
        "*.cfg",
        "*.env",
    ],
    "xml_html": [
        "*.xml",
        "*.html",
        "*.htm",
    ],
    "sql": [
        "*.sql",
    ],
    "shell": [
        "*.sh",
        "*.bat",
        "*.ps1",
    ],
    "hooks": [
        "*hook*",
        "hooks/*",
    ],
    "mcp": [
        "*mcp*",
        "*tool*",
    ],
    "notebooks": [
        "*.ipynb",
    ],
    "logs": [
        "*.log",
        "*.trace",
    ],
}

# =========================================================
# IGNORED DIRECTORIES
# =========================================================

IGNORE_DIRS = {
    ".git",
    ".venv",
    "venv",
    "__pycache__",
    "node_modules",
    "dist",
    "build",
    ".next",
    ".idea",
    ".vscode",
    ".pytest_cache",
}

# =========================================================
# TOKENIZER
# =========================================================

enc = tiktoken.get_encoding("cl100k_base")


def count_tokens(text):
    try:
        return len(enc.encode(text))
    except:
        return 0


# =========================================================
# CATEGORY DETECTION
# =========================================================


def match_patterns(path_str, patterns):
    for pattern in patterns:
        if fnmatch.fnmatch(path_str.lower(), pattern.lower()):
            return True
    return False


def categorize_file(file_path):
    path_str = str(file_path).replace("\\", "/")

    for category, patterns in CATEGORY_RULES.items():
        if match_patterns(path_str, patterns):
            return category

    return "other"


# =========================================================
# FILE SCANNING
# =========================================================


def should_ignore(path):
    parts = set(path.parts)
    return bool(parts.intersection(IGNORE_DIRS))


def read_file_content(file_path):
    try:
        return file_path.read_text(encoding="utf-8", errors="ignore")
    except:
        return ""


# =========================================================
# MAIN AUDIT
# =========================================================


def audit_project(root_path, model_context, top_n):

    category_totals = defaultdict(int)
    file_data = []

    all_files = [
        p for p in Path(root_path).rglob("*")
        if p.is_file() and not should_ignore(p)
    ]

    console.print(f"\n[bold cyan]Scanning {len(all_files)} files...[/bold cyan]\n")

    for file_path in track(all_files, description="Analyzing..."):

        content = read_file_content(file_path)

        if not content.strip():
            continue

        tokens = count_tokens(content)

        if tokens == 0:
            continue

        category = categorize_file(file_path)

        category_totals[category] += tokens

        file_data.append({
            "path": str(file_path),
            "tokens": tokens,
            "category": category
        })

    total_tokens = sum(category_totals.values())

    remaining = model_context - total_tokens
    usage_percent = (total_tokens / model_context) * 100

    # =====================================================
    # HUMAN-READABLE MODEL SUMMARY & RECOMMENDATION
    # =====================================================

    console.print(
        f"\n[bold magenta]Context Token Consumption for this Project:[/bold magenta] {total_tokens:,} tokens\n"
    )

    console.print("[bold]Available LLM Context Windows:[/bold]")
    for name, ctx in sorted(MODEL_CONTEXT_WINDOWS.items(), key=lambda x: x[1]):
        diff = ctx - total_tokens
        if diff >= 0:
            console.print(f"- {name}: {ctx:,} tokens — Remaining: {diff:,}")
        else:
            console.print(f"- {name}: {ctx:,} tokens — Short by {-diff:,} tokens")

    suitable = [ (n,c) for n,c in MODEL_CONTEXT_WINDOWS.items() if c >= total_tokens ]
    if suitable:
        best = min(suitable, key=lambda x: x[1])
        console.print(
            f"\n[bold green]Recommended model:[/bold green] {best[0]} ({best[1]:,} tokens) — fits the project tokens.\n"
        )
    else:
        largest = max(MODEL_CONTEXT_WINDOWS.items(), key=lambda x: x[1])
        shortage = total_tokens - largest[1]
        console.print(
            f"\n[bold red]No available model context fits the current tokens.[/bold red] "
            f"Largest model {largest[0]} ({largest[1]:,}) is short by {shortage:,} tokens.\n"
        )

    # =====================================================
    # CATEGORY TABLE
    # =====================================================

    table = Table(title="AI Context Token Breakdown")

    table.add_column("Category", style="cyan")
    table.add_column("Tokens", justify="right")
    table.add_column("% Usage", justify="right")

    for category, tokens in sorted(
        category_totals.items(),
        key=lambda x: x[1],
        reverse=True
    ):
        pct = (tokens / model_context) * 100
        table.add_row(category, f"{tokens:,}", f"{pct:.2f}%")

    console.print(table)

    # =====================================================
    # SUMMARY
    # =====================================================

    summary = Table(title="Context Window Summary")

    summary.add_column("Metric")
    summary.add_column("Value", justify="right")

    summary.add_row("Total Tokens", f"{total_tokens:,}")
    summary.add_row("Model Context", f"{model_context:,}")
    summary.add_row("Remaining", f"{remaining:,}")
    summary.add_row("Usage %", f"{usage_percent:.2f}%")

    console.print(summary)

    # =====================================================
    # WARNINGS
    # =====================================================

    if usage_percent > 80:
        console.print(
            "\n[bold red]WARNING:[/bold red] Context window above 80%\n"
        )
    elif usage_percent > 60:
        console.print(
            "\n[bold yellow]NOTICE:[/bold yellow] Context window above 60%\n"
        )

    # =====================================================
    # TOP FILES
    # =====================================================

    top_table = Table(title=f"Top {top_n} Largest Token Consumers")

    top_table.add_column("Tokens", justify="right")
    top_table.add_column("Category")
    top_table.add_column("File")

    for item in sorted(
        file_data,
        key=lambda x: x["tokens"],
        reverse=True
    )[:top_n]:

        top_table.add_row(
            f"{item['tokens']:,}",
            item["category"],
            item["path"]
        )

    console.print(top_table)

    # =====================================================
    # EXPORT JSON REPORT
    # =====================================================

    report = {
        "total_tokens": total_tokens,
        "model_context": model_context,
        "remaining_context": remaining,
        "usage_percent": usage_percent,
        "categories": dict(category_totals),
        "largest_files": sorted(
            file_data,
            key=lambda x: x["tokens"],
            reverse=True
        )[:top_n]
    }

    with open("token_audit_report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    console.print(
        "\n[green]Report exported:[/green] token_audit_report.json\n"
    )


# =========================================================
# ENTRYPOINT
# =========================================================


def main():

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--model",
        default="claude",
        help="claude | gpt4o | gemini | deepseek"
    )

    parser.add_argument(
        "--top",
        type=int,
        default=25,
        help="Top N files"
    )

    parser.add_argument(
        "--context",
        type=int,
        default=None,
        help="Custom context window"
    )

    args = parser.parse_args()

    if args.context:
        model_context = args.context
    else:
        model_context = MODEL_CONTEXT_WINDOWS.get(
            args.model.lower(),
            200_000
        )

    console.print(
        f"\n[bold green]Model Context Window:[/bold green] "
        f"{model_context:,} tokens\n"
    )

    audit_project(
        root_path=".",
        model_context=model_context,
        top_n=args.top
    )


if __name__ == "__main__":
    main()
