import os
import sys
import requests
from dotenv import load_dotenv
from fastmcp import FastMCP

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(dotenv_path=os.path.join(BASE_DIR, ".env"))

mcp = FastMCP(name="jira-tools")

JIRA_BASE = (os.getenv("JIRA_BASE") or "").strip().rstrip("/")
EMAIL = (os.getenv("JIRA_EMAIL") or "").strip()
TOKEN = (os.getenv("JIRA_API_TOKEN") or "").strip()
PROJECT = (os.getenv("JIRA_PROJECT_KEY") or "").strip()

if not all([JIRA_BASE, EMAIL, TOKEN, PROJECT]):
    raise ValueError(
        "Missing environment variables in .env. Required: "
        "JIRA_BASE, JIRA_EMAIL, JIRA_API_TOKEN, JIRA_PROJECT_KEY"
    )

auth = (EMAIL, TOKEN)
headers = {
    "Accept": "application/json",
    "Content-Type": "application/json",
}


def _adf_text(text: str) -> dict:
    return {
        "type": "doc",
        "version": 1,
        "content": [
            {
                "type": "paragraph",
                "content": [{"type": "text", "text": text}],
            }
        ],
    }


def _jira_request(method: str, path: str, **kwargs):
    url = f"{JIRA_BASE}{path}"
    return requests.request(method, url, auth=auth, headers=headers, **kwargs)


def _auth_error():
    return {
        "error": (
            "Jira authentication failed (401). Regenerate an API token at "
            "https://id.atlassian.com/manage-profile/security/api-tokens "
            "and set JIRA_EMAIL to your Atlassian account email in .env."
        )
    }


@mcp.tool(name="verify_jira_connection")
def verify_jira_connection():
    """Check Jira credentials and project access."""
    me = _jira_request("GET", "/rest/api/3/myself")
    if me.status_code == 401:
        return _auth_error()

    if me.status_code != 200:
        return {"error": me.text, "status_code": me.status_code}

    project = _jira_request("GET", f"/rest/api/3/project/{PROJECT}")
    if project.status_code == 404:
        return {
            "error": f"Project '{PROJECT}' not found or no access.",
            "status_code": 404,
        }
    if project.status_code != 200:
        return {"error": project.text, "status_code": project.status_code}

    user = me.json()
    proj = project.json()
    return {
        "status": "ok",
        "user": user.get("displayName") or user.get("emailAddress"),
        "project_key": proj.get("key"),
        "project_name": proj.get("name"),
    }


@mcp.tool(name="create_jira_issue")
def create_issue(
    summary: str,
    description: str = "",
    issue_type: str = "Task",
):
    """Create a Jira issue in the configured project."""
    payload = {
        "fields": {
            "project": {"key": PROJECT},
            "summary": summary,
            "issuetype": {"name": issue_type},
        }
    }
    if description:
        payload["fields"]["description"] = _adf_text(description)

    r = _jira_request("POST", "/rest/api/3/issue", json=payload)

    if r.status_code == 401:
        return _auth_error()
    if r.status_code != 201:
        return {"error": r.text, "status_code": r.status_code}

    data = r.json()
    return {
        "key": data.get("key"),
        "id": data.get("id"),
        "self": data.get("self"),
    }


@mcp.tool(name="update_jira_issue")
def update_issue(issue_key: str, summary: str):
    """Update Jira issue summary."""
    r = _jira_request(
        "PUT",
        f"/rest/api/3/issue/{issue_key}",
        json={"fields": {"summary": summary}},
    )

    if r.status_code == 401:
        return _auth_error()
    if r.status_code not in (200, 204):
        return {"error": r.text, "status_code": r.status_code}

    return {"status": "updated", "issue_key": issue_key}


@mcp.tool(name="add_jira_comment")
def add_comment(issue_key: str, comment: str):
    """Add a comment to a Jira issue."""
    r = _jira_request(
        "POST",
        f"/rest/api/3/issue/{issue_key}/comment",
        json={"body": _adf_text(comment)},
    )

    if r.status_code == 401:
        return _auth_error()
    if r.status_code != 201:
        return {"error": r.text, "status_code": r.status_code}

    return {"status": "comment added", "issue_key": issue_key}


@mcp.tool(name="move_jira_issue")
def move_issue(issue_key: str, status: str):
    """Move issue to a workflow status by name."""
    url_path = f"/rest/api/3/issue/{issue_key}/transitions"
    r = _jira_request("GET", url_path)

    if r.status_code == 401:
        return _auth_error()
    if r.status_code != 200:
        return {"error": r.text, "status_code": r.status_code}

    transitions = r.json().get("transitions", [])
    transition_id = None
    for t in transitions:
        if t["name"].lower() == status.lower():
            transition_id = t["id"]
            break

    if not transition_id:
        return {
            "error": f"Status '{status}' not found",
            "available": [t["name"] for t in transitions],
        }

    r = _jira_request(
        "POST",
        url_path,
        json={"transition": {"id": transition_id}},
    )

    if r.status_code == 204:
        return {"status": f"{issue_key} moved to {status}"}
    return {"error": r.text, "status_code": r.status_code}


if __name__ == "__main__":
    check = verify_jira_connection()
    if check.get("status") == "ok":
        print(
            f"Jira OK: {check['user']} / project {check['project_key']}",
            file=sys.stderr,
        )
    else:
        print(
            "Jira auth warning (MCP will start; fix .env then reload MCP): "
            f"{check.get('error', check)}",
            file=sys.stderr,
        )
    mcp.run()
