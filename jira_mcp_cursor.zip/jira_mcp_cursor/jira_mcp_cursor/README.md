# Jira MCP for Cursor

MCP server that creates, updates, comments on, and transitions Jira issues.

## Setup

1. Install Python 3.12+ and dependencies:

```powershell
cd C:\Users\Admin\Downloads\jira_mcp_cursor\jira_mcp_cursor
python -m pip install -r requirements.txt
```

2. Copy `.env.example` to `.env` and fill in your values.

3. Create an API token: https://id.atlassian.com/manage-profile/security/api-tokens  
   Use the **same email** as your Atlassian account for `JIRA_EMAIL`.

4. Test credentials:

```powershell
python server.py
```

If auth fails, the server exits with an error before starting MCP.

5. Restart Cursor so it loads `.cursor/mcp.json`.

## MCP tools

| Tool | Description |
|------|-------------|
| `verify_jira_connection` | Test auth and project access |
| `create_jira_issue` | Create an issue |
| `update_jira_issue` | Update summary |
| `add_jira_comment` | Add a comment |
| `move_jira_issue` | Transition by status name |

## Troubleshooting

- **401 Unauthorized**: Regenerate the API token; confirm `JIRA_EMAIL` matches your Atlassian login.
- **MCP not listed in Cursor**: Open MCP settings, ensure `jira` is enabled, then reload the window.
- **Python not found**: Use the full path in `.cursor/mcp.json` (already configured for this machine).
