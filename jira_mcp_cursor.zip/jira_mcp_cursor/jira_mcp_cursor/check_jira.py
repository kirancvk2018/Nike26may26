"""Quick Jira credential check. Run: python check_jira.py"""
import server

result = server.verify_jira_connection()
if result.get("status") == "ok":
    print("OK")
    print(f"  User:    {result['user']}")
    print(f"  Project: {result['project_key']} ({result['project_name']})")
else:
    print("FAILED")
    print(f"  {result.get('error', result)}")
    raise SystemExit(1)
